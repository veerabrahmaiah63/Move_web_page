import './App.css';
import MovieApp from './MovieApp';
import "bootstrap/dist/css/bootstrap.min.css";
// Bootstrap Bundle JS
import "bootstrap/dist/js/bootstrap.bundle.min";
function App() {
  return (
    <div className="App">
      <MovieApp></MovieApp>
    </div>
  );
}

export default App;
